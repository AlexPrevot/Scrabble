Projet Scrabble du Groupe 6 :

Voici le projet du scrabble du groupe 6 en Java Orienté Objet réalisé par Prévot Alexandre, Rosinski Raphaël, Rafanel Alexandre
Ce logiciel utilise JavaFX
Afin de lancer le projet, veuillez lancer l'exécutable "ASMR.exe" ou "ADVANCESCRABBLEMANIAREVOLUTION.jar"

Ce projet permet : 
- Sur la première fenêtre, c'est une page d'acceuil où il faut cliquer n'importe où afin d'avoir accès au menu
- Sur la deuxième fenêtre est le menu où on peut soit lancer une nouvelle partie soit en charger une
- Sur la troisème fenêtre si vous avez choisis nouvelle partie : une nouvelle fenêtre s'ouvre afin de sélectionner soit 2 ou 3 ou 4 joueurs
- Sur la troisème fenêtre si vous avez choisit charger une partie : une nouvelle fenêtre s'ouvre pour sélectionner une des trois parties sauvegardé (si il y en a)

Lorsqu'on se trouve sur la fenêtre de jeu (Fenêtre où se trouve le plateau du scrabble) :

-Vous devez piocher un nombre de septs tuiles(lettres) au début de votre premier tour.
-Durant votre tour de jeu, vous pouvez faire l'une des actions suivantes :
	- Mélanger un nombre inférieur ou égale à sept dans le sac pour en repiocher de nouveau (nombre égale de tuiles remis dans le sac)
	- Poser un mot sur le plateau (coller à un mot déjà existant si il y en a)
Enfin vous devez si vous avez posé un mot, piocher un nombre égale aux tuiles posé sur le plateau dans le sac
Vous pourrez dès lors appuyer sur le bouton "Tour suivant" ce qui donnera la main au joueur suivant.
Le chevalet s'en verra alors actualisé en fonction de chaque joueurs.

Durant une partie, vous pouvez la sauvegarder sur l'une des trois slots de sauvegarde disponibles (A vous de choisir).
ATTENTION : Vous pouvez écraser une sauvegarde déjà existante.

Le vainqueur d'une partie est celui qui obtient le plus gros score quand le sac est vide et que tout les joueurs de la parties ne peuvent plus écrire de mots 
- Soit leurs chevalet est vide 
- Soit on ne peut pas former de nouveau mot avec les tuiles restantes

Une fois qu'une partie est finie, on peux si on le souhaite, revenir au menu du jeu.

IMPORTANT :

Au début de la partie et de chaque tour, il faut que tout les participants qès leur premier tour, pioche dans le sac sept tuiles en cliquant dessus et en les posant sur votre chevalet.
Durant une partie, afin de mélanger des tuiles de votre chevalet dans le sac, il faut faire glisser toutes les tuiles que vous souhaiter changer sur l'image du sac et ensuite
cliquer sur le sac. ATTENTION, il n'est possible de mélanger ses tuiles, qu'une fois par tour.
Pour écrire un mot sur le plateau, il faut faire glisser les tuiles de votre chevalet sur le plateau, qui par la suite illuminera la ligne et la colonne sur laquelle vous avez le droit d'écrire.