package controller;

import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import model.Chevalet;
import model.Joueur;
import model.Lettre;
import model.Plateau;
import model.Sac;
import view.Fenetre;
import view.Menu;

public class Souris {
	static private double mousePlateauX = 0;
	static private double mousePlateauY = 0;
	static private int mousePlateauTabX = 0;
	static private int mousePlateauTabY = 0;
	
	static private boolean mouseInPartie = false;
	
	static private double mouseChevaletX = 0;
	static private double mouseChevaletY = 0;
	static private boolean mouseInChevalet = false;
	
	static private boolean modeDownChevalet = false;
	static private boolean modeUpChevalet = true;
	
	static private Group part;
	static private Pane plat;
	static private Pane chev;
	static private Pane bag;
	static private Pane sauvegarde1;
	
	static private Lettre movingLetter;
	
	static public void mouseAction(Group partie, Pane plateau, Pane chevalet, Pane sac, Pane valider, Pane retourMenu,Pane boutonSauvegarder,Pane save1, Pane sauvegarde2, Pane sauvegarde3) {
		part = partie;
		plat = plateau;
		chev = chevalet;
		bag = sac;
		sauvegarde1 = save1;
		
		valider.setOnMousePressed(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent arg0) {
				Fenetre.pressButtonValider();
			}
		});
		
		valider.setOnMouseReleased(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent arg0) {
				Plateau.changeTour();
			}
		});
		
		plateau.setOnMousePressed(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent arg0) {
				clicNdropPlat();
			}
		});
		
		
		plateau.setOnMouseMoved(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				mousePlateauX = event.getX();
				mousePlateauY = event.getY();
				mousePlateauTabX = Fenetre.convertXToTabX(mousePlateauX);
				mousePlateauTabY = Fenetre.convertYToTabY(mousePlateauY);
				
				if(!(movingLetter == null)) {
					moveLetter();
				}
								
				if(mousePlateauY > 440) {
					if(modeUpChevalet) {
						Fenetre.upChevalet();
						modeUpChevalet = false;
						modeDownChevalet = true;
					}
				}else {
					if(modeDownChevalet) {
						Fenetre.downChevalet();
						modeDownChevalet = false;
					}
					modeUpChevalet = true;
				}
				
			}
			
		});
		
		
		chevalet.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				
				mouseInChevalet = true;
				Fenetre.upChevalet();

				chevalet.setOnMouseMoved(new EventHandler<MouseEvent>() {

					@Override
					public void handle(MouseEvent event) {
						mouseChevaletX = event.getX();
						mouseChevaletY = event.getY();
						
					}
					
				});
			}
			
		});
		
		chevalet.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				
				mouseInChevalet = false;
				
			}
			
		});
		
		partie.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				
				mouseInPartie = true;
				
			}
			
		});
		
		partie.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				
				mouseInPartie = false;
				
			}
			
		});
		
		sac.setOnMouseClicked(new EventHandler<MouseEvent>(){
			
			@Override
			public void handle(MouseEvent event) {
				if(movingLetter == null) {
					piocherUneLettre();
				}
			}
			
		});
		
		retourMenu.setOnMouseClicked(new EventHandler<MouseEvent>(){
			
			@Override
			public void handle(MouseEvent event) {
				if(Fenetre.getWhatBoxIsOpen() == "victoire") Fenetre.fermerVictoire();
				if(Fenetre.getWhatBoxIsOpen() == "fenetre") Fenetre.fermerJeu();
				
				Sac.getToutesLesLettres().clear();
				
				 try {
				      Menu.ouvrireMenu();
				    } catch (Exception e) {
				      System.out.println(e);
				    }
				
			}
			
		});
		
		boutonSauvegarder.setOnMouseClicked(new EventHandler<MouseEvent>(){
			
			@Override
			public void handle(MouseEvent event) {
				Fenetre.sauvegardeScreen();
			}
			
		});
		
		sauvegarde1.setOnMouseClicked(new EventHandler<MouseEvent>(){
			
			@Override
			public void handle(MouseEvent event) {
				Fenetre.fermerSave();
				Plateau.saveGame("src/toUse/save1.txt");
			}
			
		});
		
		sauvegarde2.setOnMouseClicked(new EventHandler<MouseEvent>(){
			
			@Override
			public void handle(MouseEvent event) {
				Fenetre.fermerSave();
				Plateau.saveGame("src/toUse/save2.txt");
			}
			
		});	
		
		sauvegarde3.setOnMouseClicked(new EventHandler<MouseEvent>(){
			
			@Override
			public void handle(MouseEvent event) {
				Fenetre.fermerSave();
				Plateau.saveGame("src/toUse/save3.txt");
			}
			
		});	
		
		
		
	}
	
	static private void piocherUneLettre() {
		if(!Sac.isEmpty()) movingLetter = Sac.piocheLettre();
		if(!(movingLetter == null)) {
			plat.getChildren().add(movingLetter.getImageView());
			moveLetter();
		}
	}
	
	static private void moveLetter() {
		movingLetter.getImageView().setLayoutX(mousePlateauX-movingLetter.getImageView().getFitWidth()/2);
		movingLetter.getImageView().setLayoutY(mousePlateauY-movingLetter.getImageView().getFitHeight()/2);
	}
	
	static private void clicNdropPlat() {
		if (movingLetter == null) {
			if(mouseInPartie() || mouseInChevalet()) {
				if(mouseInChevalet()) {
					movingLetter = Plateau.getJoueurActif().getChevalet().whatPiece(mouseChevaletX, mouseChevaletY);
					if(!(movingLetter == null)) {
						movingLetter.getImageView().setFitHeight(Fenetre.getHeightCase());
						movingLetter.getImageView().setFitWidth(Fenetre.getWidthCase());
						Fenetre.getChevalet().getChildren().remove(movingLetter.getImageView());
					}
				}else {
					if(!Plateau.getCase(mousePlateauTabX, mousePlateauTabY).getLocked()) movingLetter = Plateau.getCase(mousePlateauTabX, mousePlateauTabY).getCaseLettre();
					if(!(movingLetter == null)) {
						Plateau.getCase(mousePlateauTabX, mousePlateauTabY).emptyCase();
						Fenetre.getPartie().getChildren().remove(movingLetter.getImageView());
					}
				}
				if(!(movingLetter == null)) {
					Fenetre.getPlateau().getChildren().add(movingLetter.getImageView());
					moveLetter();
				}
			}
		}else {
			Fenetre.getPlateau().getChildren().remove(movingLetter.getImageView());
			if(!(mouseInSac())) {
				if(mouseInChevalet()) {
					movingLetter.setOnChevalet(true);
					Plateau.getJoueurActif().getChevalet().addPiece(movingLetter, movingLetter.getImageView().getLayoutX() - Fenetre.getChevalet().getLayoutX(), movingLetter.getImageView().getLayoutY()-Fenetre.getChevalet().getLayoutY());
				}else {
					if(!(movingLetter.getCoordX() == -1) || (mouseInPartie() || mouseInChevalet())) {
						if(mouseInPartie()) {							
							if(Plateau.getCase(mousePlateauTabX, mousePlateauTabY).getCanBeFilled()) {
								movingLetter.setOnChevalet(false);
								Plateau.putLetterOn(Plateau.getCase(mousePlateauTabX, mousePlateauTabY), movingLetter);
							}else {
								if(movingLetter.getOnChevalet()) {
									Plateau.getJoueurActif().getChevalet().addPiece(movingLetter, movingLetter.getCoordX(), movingLetter.getCoordY());
								}else if(movingLetter.isOnPlat()){
									Plateau.putLetterOn(Plateau.getCase(movingLetter.getCoordX(), movingLetter.getCoordY()), movingLetter);
								}else {
									Plateau.getJoueurActif().getChevalet().addPiece(movingLetter, movingLetter.getCoordX(), movingLetter.getCoordY());
								}
							}
						}else{
							if(movingLetter.getOnChevalet()) {
								movingLetter.setOnChevalet(true);
								Plateau.getJoueurActif().getChevalet().addPiece(movingLetter, movingLetter.getCoordX(), movingLetter.getCoordY());
							}else{
								movingLetter.setOnChevalet(false);
								Plateau.putLetterOn(Plateau.getCase(movingLetter.getCoordX(), movingLetter.getCoordY()), movingLetter);
							}
						}
					}else {
						Plateau.getJoueurActif().getChevalet().addPiece(movingLetter, movingLetter.getCoordX(), movingLetter.getCoordY());
					}
				}
			}else {
				if(!Plateau.getJoueurActif().getHasFlushed()) {
					Sac.addlettre(movingLetter);
				}else {
					if(movingLetter.getOnChevalet()) {
						movingLetter.setOnChevalet(true);
						Plateau.getJoueurActif().getChevalet().addPiece(movingLetter, movingLetter.getCoordX(), movingLetter.getCoordY());
					}else{
						if(movingLetter.isOnPlat()) {
							movingLetter.setOnChevalet(false);
							Plateau.putLetterOn(Plateau.getCase(movingLetter.getCoordX(), movingLetter.getCoordY()), movingLetter);
						
						}else {
							movingLetter.setOnChevalet(true);
							Plateau.getJoueurActif().getChevalet().addPiece(movingLetter, movingLetter.getCoordX(), movingLetter.getCoordY());
						}
					}
				}
			}
			movingLetter = null;
		}
	}
	
	static private boolean mouseInChevalet() {
		return mousePlateauX > Fenetre.getChevalet().getLayoutX() && mousePlateauX < Fenetre.getChevalet().getLayoutX() + Fenetre.getChevalet().getWidth() && mousePlateauY >  Fenetre.getChevalet().getLayoutY();
	}
	
	static private boolean mouseInPartie() {
		return !(mousePlateauTabX > 14 || mousePlateauTabX < 0 || mousePlateauTabY > 14 || mousePlateauTabY < 0);
	}
	
	static private boolean mouseInSac() {
		return mousePlateauX > bag.getLayoutX() && mousePlateauX < bag.getLayoutX() + bag.getWidth() && mousePlateauY > bag.getLayoutY() && mousePlateauY < bag.getLayoutY() + bag.getWidth();
	}
	
	static public double getMousePlateauTabX() {
		return mousePlateauTabX;
	}
	
	static public double getMousePlateauTabY() {
		return mousePlateauTabY;
	}
	
	static public double getMouseChevaletX() {
		return mouseChevaletX;
	}
	
	static public double getMouseChevaletY() {
		return mouseChevaletY;
	}
	
	
}
