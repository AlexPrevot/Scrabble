package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.StringTokenizer;

import java.util.ArrayList;

import view.Fenetre;

public class Plateau {
	static public Case[][] tableau;
	
	static public String folderPath ="src/toUse/Dictionnaire/";
	static public File wordFolder = new File(folderPath);
	
	static public Joueur joueurActif;
	
	static public Case lastCaseFilled;
		
	static public boolean modePoseVertical = true;
	static public boolean modePoseHorizontal = true;
	static private boolean firstTour = true;
	
	static public void initialiserPlateau() {
		firstTour = true;
		 tableau = new Case[15][15];
		for(int i = 0; i < 15; i++) {
			for(int j = 0; j < 15; j++) {
				tableau[i][j] = new Case(j,i);
			}
		}
		setCasesBonus();
	}
	
	static public ArrayList<String> getAllWords() {
		ArrayList<String> listMot = new ArrayList<String>();
		Case c = getCase(joueurActif.getLettrePose().get(0).getCoordX(),joueurActif.getLettrePose().get(0).getCoordY());
		boolean lettreADroite = false;
		boolean lettreAGauche = false;
		boolean lettreAuDessus = false;
		boolean lettreEnDessous = false;
		
		
		
		if(modePoseHorizontal) {
			for(Lettre l : joueurActif.getLettrePose()) {
				if(getCase(l.getCoordX(), l.getCoordY() + 1) != null) lettreEnDessous = getCase(l.getCoordX(), l.getCoordY() + 1).getFilled();
				else lettreEnDessous = false;
				if(getCase(l.getCoordX(), l.getCoordY() - 1) != null) lettreAuDessus  = getCase(l.getCoordX(), l.getCoordY() - 1).getFilled();
				else lettreAuDessus = false;
				
				if(lettreAuDessus || lettreEnDessous) {
					listMot.add(getWordVertical(getCase(l.getCoordX(), l.getCoordY())));
				}
			}
			if(joueurActif.getLettrePose().size() > 1) 	listMot.add(0,getWordHorizontal(c));
		}
			
		if(modePoseVertical) {
			for(Lettre l : joueurActif.getLettrePose()) {
				if(getCase(l.getCoordX() + 1, l.getCoordY()) != null) lettreADroite = getCase(l.getCoordX() + 1, l.getCoordY()).getFilled();
				else lettreADroite = false;
				if(getCase(l.getCoordX() - 1, l.getCoordY()) != null) lettreAGauche = getCase(l.getCoordX() - 1, l.getCoordY()).getFilled();
				else lettreAGauche = false;
				
				if(lettreADroite || lettreAGauche) {
					listMot.add(getWordHorizontal(getCase(l.getCoordX(), l.getCoordY())));
				}
			}
			if(joueurActif.getLettrePose().size() > 1) listMot.add(0,getWordVertical(c));
		}
		
		if(listMot.size() == 0) listMot.add(0,c.getCaseLettre().getLettre() +"");
		
		//CA RETOURNE UNE LISTE DONT LE PREMIER ELEMENT EST LE MOT ORIGINAL QUI ETAIT PRODUIT
		return listMot;
	}
	
	static private void clearPlateau() {
		initialiserPlateau();
	}
	
	static public void clearGame() {
		clearPlateau();
		Joueur.clearJoueur();
	}
	
	static public String getWordHorizontal(Case c) {
		String motARetourner = "";
		
		int cXor = c.getCoordX();
		int cYor = c.getCoordY();
		
		int cXfin = cXor;
		
		int cXdebut = cXor;
		
		for(int i = cXor; i < 15; i++) {
			if(tableau[cYor][i].getFilled()) cXfin = i;
			else break;
		}
		
		for(int i = cXor; i >= 0; i--) {
			if(tableau[cYor][i].getFilled()) cXdebut = i;
			else break;
		}
		
		for(int i = cXdebut; i <= cXfin; i++) {
			motARetourner += tableau[cYor][i].getCaseLettre().getLettre();
		}
				
		return motARetourner;
	}
	
	static private String getWordVertical(Case c) {
		String motARetourner = "";
		
		int cXor = c.getCoordX();
		int cYor = c.getCoordY();
		
		int cYfin = cYor;
		
		int cYdebut = cYor;
		for(int i = cYor; i < 15; i++) {
			if(tableau[i][cXor].getFilled()) cYfin = i;
			else break;
		}

		
		for(int i = cYor; i >= 0; i--) {
			if(tableau[i][cXor].getFilled()) cYdebut = i;
			else break;
		}
		
		for(int i = cYdebut; i <= cYfin; i++) {
			motARetourner += tableau[i][cXor].getCaseLettre().getLettre();
		}
		
		return motARetourner;
	}
	
	static public Case[][]getTableau() {
		return tableau;
	}
	
	static public Case getCase(int x, int y) {
		if(x >= 0 && x < 15 && y >= 0 && y < 15) return tableau[y][x];
		else return null;
		
	}
	
	static public void putLetterOn(Case c, Lettre l) {
		l.setOnPlat(true);
		c.fillCaseWith(l);
		Fenetre.showLetterOnPlat(l, c.getCoordX(), c.getCoordY());
		lastCaseFilled = c;
		
		restrictPlateau(c);
		
		joueurActif.addLettrePose(l);
		
		Fenetre.hideNonAccessibleCase();
		
	}
	
	
	static public void restrictPlateau(Case c) {
		for(int i = 0; i < 15; i++) {
			for(int j = 0; j < 15; j++) {
				if(!(c.getCoordX() == j || c.getCoordY() == i)){
					tableau[i][j].setCanBeFilled(false);
				}
			}
		}
	}
	
	static public void actualiseGame() {
		resetPose();
		lockCases();
		Fenetre.hideNonAccessibleCase();
	}
	
	static public void lockCases() {
		for(int i = 0; i < 15; i++) {
			for(int j = 0; j < 15; j++) {
				if(tableau[i][j].getFilled()) {
					tableau[i][j].lockCase();
				}
			}
		}
	}
	
	static public void resetPose() {
		for(int i = 0; i < 15; i++) {
			for(int j = 0; j < 15; j++) {
				tableau[i][j].setCanBeFilled(true);
			}
		}
		modePoseHorizontal = true;
		modePoseVertical = true;
	}
	
	static private File whatFile(char a) {
		File fileToReturn;
		
		fileToReturn = new File(folderPath + a + ".txt");
		if(fileToReturn.exists()) return fileToReturn;
		else {
			//Si la premi�re lettre qu'il a mit n'est pas dans l'alphabet, on fait comme si il avait utilis� un mot qui commence par A
			System.out.println("Le fichier texte n'existe pas !!!!!!!!");
			return new File(folderPath + "A.txt");
		}
	}
	
	static public void saveGame(String path) {
		ArrayList<Object> data = new ArrayList<Object>();
		
		data.add(Sac.getToutesLesLettres());
		data.add(Sac.getListLettre());
		data.add(Joueur.getListJoueur());
		data.add(joueurActif);
		data.add(tableau);
		
		
		try {
			//FileOutputStream fileOut = new FileOutputStream("src/toUse/memory.txt");
			FileOutputStream fileOut = new FileOutputStream(path);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(data);
			out.close();
			fileOut.close();
		}catch(IOException i) {
			i.printStackTrace();
		}
	}
	
	static public void loadGame(String path) {
		ArrayList<Object> dataLoader = new ArrayList<Object>();
		
		try {
			FileInputStream fileIn = new FileInputStream(path);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			dataLoader = (ArrayList<Object>) in.readObject();
			in.close();
			fileIn.close();
		}catch(IOException i) {
			i.printStackTrace();
			
		}catch(ClassNotFoundException c) {
			c.printStackTrace();
		}
		Joueur.setListJoueur((ArrayList<Joueur>) dataLoader.get(2));
		joueurActif = (Joueur) dataLoader.get(3);
		Fenetre f = new Fenetre();
		f.ouvrirJeu();
		Fenetre.getListLettreGraphique().clear();
		Sac.loadSacAndLettre((ArrayList<Lettre>) dataLoader.get(1), (ArrayList<Lettre>) dataLoader.get(0));
		Fenetre.displaySac("file:src/toUse/image/pioche.png");
		tableau = (Case[][]) dataLoader.get(4);
		
		Fenetre.hideNonAccessibleCase();
		Fenetre.updateChevalet(Plateau.getJoueurActif().getChevalet());
	}
	
	
	static public boolean doWordExists(String s) {
		s = s.toUpperCase();
		char firstLetter = s.charAt(0);
		
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(whatFile(firstLetter))));
			String line = reader.readLine();
			
			while(line != null) {
				if(line.equals(s)) {
					reader.close();
					return true;
				}
				line = reader.readLine();
			}
			
			reader.close();
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	static public void changeTour() {
		ArrayList<String> s = new ArrayList<String>();
		if(!joueurActif.getLettrePose().isEmpty()) s = getAllWords();
		if(s.size() != 0) Fenetre.displayWord(s);

		
		if(joueurActif.getLettrePose().isEmpty()) {
			joueurActif.setTurnPassed(true);
			changePlayerTurn();
		}else if(lettrePoseAttache() && areAllWordsValid(s) && (areAllWordAttached() || isInTheMiddleANDFirstTour())){
			joueurActif.setTurnPassed(false);
			firstTour = false;
			joueurActif.retrieveScoreActivePlayer(s);
			
			joueurActif.setHasFlushed(false);
			
			joueurActif.getLettrePose().clear();
			
			
			changePlayerTurn();
		
		}
	}
	
	static private void changePlayerTurn() {

		if(!isVictory()) {
			Fenetre.hideChevalet(joueurActif.getChevalet());
			joueurActif = Joueur.getListJoueur().get((Joueur.getListJoueur().indexOf(joueurActif) + 1)%(Joueur.getListJoueur().size()));
			Fenetre.updateChevalet(joueurActif.getChevalet());
			
			actualiseGame();
		}
	}
	
	static public boolean isVictory() {
		int lePlusGrosScore = 0;
		Joueur joueurGagnant = joueurActif;
		boolean tourComplet = true;
		
		for(Joueur j : Joueur.getListJoueur()) {
			if(lePlusGrosScore < j.getScore()) {
				lePlusGrosScore = j.getScore();
				joueurGagnant = j;
				tourComplet = tourComplet && j.getTurnPassed();
			}
		}

		
		if((joueurActif.getChevalet().getListLettre().size() == 0 && Sac.isEmpty()) || tourComplet && Sac.isEmpty()) {
			Joueur.setVictorious(joueurGagnant);
			Fenetre.showVictoryBox();
			return true;
		}
		else return false;
	}
	
	static public boolean isInTheMiddleANDFirstTour() {
		return firstTour && Plateau.getCase(7,7).getFilled();
	}
	
	static public boolean areAllWordAttached() {
		if(firstTour) return true;
		for(Lettre l : joueurActif.getLettrePose()) {
			if(contactLettreOfPosedWord(l, joueurActif.getLettrePose())) return true;
		}
		return false;
			
	}
	
	static private boolean contactLettreOfPosedWord(Lettre l, ArrayList<Lettre> lettrePose) {
		boolean lettreAuDessus = false;
		boolean lettreEnDessous = false;
		boolean lettreADroite = false;
		boolean lettreAGauche = false;
		
		if(getCase(l.getCoordX() + 1, l.getCoordY()) != null) lettreADroite = getCase(l.getCoordX() + 1, l.getCoordY()).getFilled() && !lettrePose.contains( getCase(l.getCoordX() + 1, l.getCoordY()).getCaseLettre());
		else lettreADroite = false;
		if(getCase(l.getCoordX() - 1, l.getCoordY()) != null) lettreAGauche = getCase(l.getCoordX() - 1, l.getCoordY()).getFilled() && !lettrePose.contains( getCase(l.getCoordX() -1, l.getCoordY()).getCaseLettre());
		else lettreAGauche = false;
		if(getCase(l.getCoordX(), l.getCoordY() + 1) != null) lettreEnDessous = getCase(l.getCoordX(), l.getCoordY() + 1).getFilled() && !lettrePose.contains( getCase(l.getCoordX(), l.getCoordY() + 1).getCaseLettre());
		else lettreEnDessous = false;
		if(getCase(l.getCoordX(), l.getCoordY() - 1) != null) lettreAuDessus = getCase(l.getCoordX(), l.getCoordY() - 1).getFilled() && !lettrePose.contains( getCase(l.getCoordX(), l.getCoordY() - 1).getCaseLettre());
		else lettreAuDessus= false;
		
		return lettreAuDessus || lettreEnDessous || lettreADroite || lettreAGauche;
	}
	
	static public boolean areAllWordsValid(ArrayList<String> s) {
		boolean b = true;
		
		for(String st : s) {
			if(!doWordExists(st)) b = false;
		}
		
		
		return b;
	}
	
	static public boolean lettrePoseAttache() {
		boolean b = true;
		boolean lettreADroite = false;
		boolean lettreEnDessous = false;
		
		for(Lettre l : joueurActif.getLettrePose()) {
			if(modePoseHorizontal) {
				if(getCase(l.getCoordX() + 1,l.getCoordY()) != null) lettreADroite = getCase(l.getCoordX() + 1,l.getCoordY()).getFilled();
				else lettreADroite = true;
				if(!lettreADroite && (joueurActif.getLettrePose().indexOf(l) != joueurActif.getLettrePose().size()-1)) {
					b = false;
				}
			}
			if(modePoseVertical) {
				if(getCase(l.getCoordX(),l.getCoordY() + 1) != null) lettreEnDessous = getCase(l.getCoordX(),l.getCoordY() + 1).getFilled();
				else lettreEnDessous = true;
				if(!lettreEnDessous && (joueurActif.getLettrePose().indexOf(l) != joueurActif.getLettrePose().size()-1)) {
					b = false;
				}
			}
		}
		
		return b;
	}
	
	static public void setJoueurActif(Joueur j) {
		joueurActif = j;
	}
	
	static public Joueur getJoueurActif() {
		return joueurActif;
	}
	
	static public Case getLastCaseFilled() {
		return lastCaseFilled;
	}
	
	static public boolean getPoseVertical() {
		return modePoseVertical;
	}
	
	static public boolean getPoseHorizontal() {
		return modePoseHorizontal;
	}
	
	static public void setPoseVertical(boolean b) {
		modePoseVertical = b;
	}
	
	static public void setPoseHorizontal(boolean b) {
		modePoseHorizontal = b;
	}
	
	
	

public static void setCasesBonus(){

  Case[][] cases = tableau;

 
  // mot double sur les diagonales case rose
  for (int i = 1; i < 14; i++) {
    if (!(i == 5 || i == 6 || i == 8 || i == 9)) {
    	cases[i][i].setBonus("MD");
    	cases[i][14 - i].setBonus("MD");
    }
  }

  // Mot triple case rouge
  cases[0][0].setBonus("MT");
  cases[0][7].setBonus("MT");
  cases[7][0].setBonus("MT");
  cases[0][14].setBonus("MT");
  cases[7][14].setBonus("MT");
  cases[14][0].setBonus("MT");
  cases[14][7].setBonus("MT");
  cases[14][14].setBonus("MT");

  // Lettre Double bleu ciel
  cases[3][0].setBonus("LD");
  cases[11][0].setBonus("LD");
  cases[6][2].setBonus("LD");
  cases[8][2].setBonus("LD");
  cases[0][3].setBonus("LD");
  cases[14][3].setBonus("LD");
  cases[2][6].setBonus("LD");
  cases[2][8].setBonus("LD");
  cases[6][6].setBonus("LD");
  cases[6][8].setBonus("LD");
  cases[8][6].setBonus("LD");
  cases[8][8].setBonus("LD");
  cases[12][6].setBonus("LD");
  cases[12][8].setBonus("LD");
  cases[0][11].setBonus("LD");
  cases[14][11].setBonus("LD");
  cases[8][12].setBonus("LD");
  cases[6][12].setBonus("LD");
  cases[3][14].setBonus("LD");
  cases[11][14].setBonus("LD");
  cases[11][7].setBonus("LD");
  cases[3][7].setBonus("LD");
  cases[7][3].setBonus("LD");
  cases[7][11].setBonus("LD");

  // Lettre triple bleue fonc�
  cases[5][1].setBonus("LT");
  cases[9][1].setBonus("LT");
  cases[1][5].setBonus("LT");
  cases[5][5].setBonus("LT");
  cases[9][5].setBonus("LT");
  cases[13][5].setBonus("LT");
  cases[1][9].setBonus("LT");
  cases[5][9].setBonus("LT");
  cases[9][9].setBonus("LT");
  cases[13][9].setBonus("LT");
  cases[5][13].setBonus("LT");
  cases[9][13].setBonus("LT");
}


}
