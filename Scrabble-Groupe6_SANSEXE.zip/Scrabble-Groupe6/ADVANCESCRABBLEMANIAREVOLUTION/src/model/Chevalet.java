package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

import view.Fenetre;

public class Chevalet implements Serializable{
	ArrayList<Lettre> lettreChevalet = new ArrayList<Lettre>();
	
	public Chevalet() {
		
	}
	
	public void addPiece(Lettre l, double posX, double posY) {
		lettreChevalet.add(l);		
		if(posX > 0) l.setCoord((int) posX,(int) posY);
		else l.setCoord((int) (50 + lettreChevalet.indexOf(l) * (Fenetre.getWidthCase() + 15)), 50);
		Fenetre.updateChevalet(this);
	}
	
	public void removePiece(Lettre l) {
		lettreChevalet.remove(l);
	}
	
	public Lettre getPiece(int x,int y) {
		return lettreChevalet.get(x);
	}
	
	public Lettre whatPiece(double coordX, double coordY) {
		int cX = (int) coordX;
		int cY = (int) coordY;
		Lettre l;
		
		Iterator i = this.lettreChevalet.iterator();
		
		while(i.hasNext()) {
			l = (Lettre) i.next();
			if(cX > l.getCoordX() && cX <l.getCoordX() + l.getImageView().getFitWidth() && cY > l.getCoordY() && cY < l.getCoordY() + l.getImageView().getFitHeight()) {
				lettreChevalet.remove(l);
				return l;
			}
		}
		
		return null;
	}
	
	public ArrayList<Lettre> getListLettre(){
		return this.lettreChevalet;
	}

}
