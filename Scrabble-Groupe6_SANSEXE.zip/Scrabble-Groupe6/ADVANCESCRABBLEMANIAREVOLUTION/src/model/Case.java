package model;

import java.io.Serializable;

import view.Fenetre;

public class Case implements Serializable{
	int coordX;
	int coordY;
	boolean filled;
	boolean canBeFilled;
	boolean locked;
	int caseBonusScore = 1;
	int wordBonusScore = 1;
	Lettre caseLettre;
	public Case(int coordX, int coordY) {
		filled = false;
		canBeFilled = true;
		locked = false;
		this.coordX = coordX;
		this.coordY = coordY;
	}
	
	public Lettre getCaseLettre() {
		return this.caseLettre;
	}
	
	public void fillCaseWith(Lettre l){
		filled = true;
		this.caseLettre = l;
		l.setCoord(this.coordX, this.coordY);
		canBeFilled = false;
	}
	
	public void emptyCase() {
		Plateau.getJoueurActif().lettrePose.remove(this.getCaseLettre());
		this.caseLettre = null;
		filled = false;
		canBeFilled = true;
		if(Plateau.getJoueurActif().getLettrePose().size() == 1) {
			Plateau.resetPose();
			Plateau.restrictPlateau(Plateau.getCase(Plateau.getJoueurActif().getLettrePose().get(0).getCoordX(), Plateau.getJoueurActif().getLettrePose().get(0).getCoordY()));
		}
		if(Plateau.getJoueurActif().getLettrePose().size() == 0) Plateau.resetPose();
		
		Fenetre.hideNonAccessibleCase();
	}
	
	public boolean getFilled() {
		return this.filled;
	}
	
	public int getCoordX() {
		return this.coordX;
	}
	
	public int getCoordY() {
		return this.coordY;
	}
	
	public boolean getLocked() {
		return locked;
	}
	
	public void lockCase() {
		locked = true;
	}
	
	public boolean getCanBeFilled() {
		return (canBeFilled && !filled);
	}
	
	public void setCanBeFilled(boolean b) {
		canBeFilled = b;
	}
	
	public int getCaseBonus() {
		return caseBonusScore;
	}
	
	public int getWordBonus() {
		return wordBonusScore;
	}
	
	public void setBonus(String b){
		  switch (b) {
		  case "LD": {
			caseBonusScore = 2;
		    break;
		  }
		  case "MD": {
		    wordBonusScore = 2;
		    break;
		  }
		  case "LT": {
			caseBonusScore = 3;
			 break;
		  }
		  case "MT": {
		    wordBonusScore = 3;
		    break;
		  }
		 }
	}

}
