package model;

import java.util.ArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;
import view.Fenetre;

public class Sac {
	
	static boolean modeFlush = false;
	static int nbrLetterToFlush = 0;
	static ArrayList<Lettre> listLettre = new ArrayList<Lettre>();
	static ArrayList<Lettre> toutesLesLettres = new ArrayList<Lettre>();
	
	static public void initializeSac() {
		int nbrLettre =0;
		char l = 'a';
		
		listLettre.clear();
		
		for(int k = 0; k < 26; k++) {
			switch(k) {
			case 0:
				nbrLettre = 9;
				l = 'A';
				break;
			case 1:
				nbrLettre = 2;
				l = 'B';
				break;
			case 2:
				nbrLettre = 2;
				l = 'C';
				break;
			case 3:
				nbrLettre = 3;
				l = 'D';
				break;
			case 4:
				nbrLettre = 15;
				l = 'E';
				break;
			case 5:
				nbrLettre = 2;
				l = 'F';
				break;
			case 6:
				nbrLettre = 2;
				l = 'G';
				break;
			case 7:
				nbrLettre = 2;
				l = 'H';
				break;
			case 8:
				nbrLettre = 8;
				l = 'I';
				break;
			case 9:
				nbrLettre = 1;
				l = 'J';
				break;
			case 10:
				nbrLettre = 1;
				l = 'K';
				break;
			case 11:
				nbrLettre = 5;
				l = 'L';
				break;
			case 12:
				nbrLettre = 3;
				l = 'M';
				break;
			case 13:
				nbrLettre = 6;
				l = 'N';
				break;
			case 14:
				nbrLettre = 6;
				l = 'O';
				break;
			case 15:
				nbrLettre = 2;
				l = 'P';
				break;
			case 16:
				nbrLettre = 1;
				l = 'Q';
				break;
			case 17:
				nbrLettre = 6;
				l = 'R';
				break;
			case 18:
				nbrLettre = 6;
				l = 'S';
				break;
			case 19:
				nbrLettre = 6;
				l = 'T';
				break;
			case 20:
				nbrLettre = 6;
				l = 'U';
				break;
			case 21:
				nbrLettre = 2;
				l='V';
				break;
			case 22:
				nbrLettre = 1;
				l='W';
				break;
			case 23:
				nbrLettre = 1;
				l = 'X';
				break;
			case 24:
				nbrLettre = 1;
				l = 'Y';
				break;
			case 25:
				nbrLettre = 1;
				l = 'Z';
				break;
			}
			for(int m = 0; m < nbrLettre; m++) {
				listLettre.add(new Lettre(l));
				
			}
		}
		
		
		for(Lettre l1 : listLettre) {
			toutesLesLettres.add(l1);
		}
	}
	
	static public void loadSacAndLettre(ArrayList<Lettre> listLettre2, ArrayList<Lettre> toutesLesLettres2) {
		toutesLesLettres.clear();
		listLettre.clear();
		toutesLesLettres = toutesLesLettres2;
		listLettre = listLettre2;
		
		for(Lettre l : toutesLesLettres) {
			Fenetre.initializeViewLetter(l);
		}
	}
	
	static public ArrayList<Lettre> getToutesLesLettres() {
		return toutesLesLettres;
	}
	
	static public ArrayList<Lettre> getListLettre(){
		return listLettre;
	}
		
	static public Lettre piocheLettre() {
		if(Plateau.getJoueurActif().getLettrePose().size() + Plateau.getJoueurActif().getChevalet().getListLettre().size() < 7) {
			int rd = (int) (Math.random()*(listLettre.size()));	
			Fenetre.animationSacPioche(1);
			
			if(modeFlush) {
				Fenetre.animationSacPioche(1);
				returnFlushedLetters();
				if(listLettre.size()-nbrLetterToFlush == 0) Fenetre.displaySac("file:src/toUse/image/empty.png");
				else Fenetre.displaySac("file:src/toUse/image/pioche.png");
				Plateau.getJoueurActif().setHasFlushed(true);
				return null;
			}
			
			if(listLettre.size()-1 == 0) Fenetre.displaySac("file:src/toUse/image/empty.png");
			
			return listLettre.remove(rd);
		}else return null;
	}
	
	static public boolean isEmpty() {
		return listLettre.isEmpty();
	}
	
	static public void addlettre(Lettre l) {
		Fenetre.displaySac("file:src/toUse/image/flush.png");
		
		modeFlush = true;
		nbrLetterToFlush++;
		l.resetLettre();
		listLettre.add(l);
	}
	
	static public void returnFlushedLetters() {
		for(int i = 0; i < nbrLetterToFlush; i++) {
			int rd = (int) (Math.random()*(listLettre.size()));		
			Plateau.getJoueurActif().getChevalet().addPiece(listLettre.remove(rd), -1, -1);
		}
		nbrLetterToFlush = 0;
		modeFlush = false;
	}
}
