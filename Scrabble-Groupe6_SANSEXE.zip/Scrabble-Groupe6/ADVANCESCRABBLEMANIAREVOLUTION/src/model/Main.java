package model;

import view.Fenetre;

public class Main {
	public static void main(String[] args) {
		Fenetre.ouvrirFenetre(args, "menu");
		}
}