package model;

import view.Fenetre;

public class Scrabble {
	static public void newGame() {
		Plateau.initialiserPlateau();
		Sac.initializeSac();
		Fenetre f = new Fenetre();
		f.ouvrirJeu();
	}
	
	static public void loadGame(String path) {
		System.out.println("je charge le jeu");
		Plateau.loadGame(path);
	}
	
}
