package model;

import java.io.Serializable;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import view.Fenetre;

public class Lettre implements Serializable{
	private char lettre;
	private int score;
	//private ImageView imageOnPlat;
	private int posImageView;
	private int coordX = -1;
	private int coordY = -1;
	private boolean onChevalet = false;
	private boolean onPlat = false;
	
	public Lettre(char s) {
		this.lettre = s;
		Fenetre.initializeViewLetter(this);
		//setPNG();
		this.score = getScoreChar(s);
	}
	
	public void setOnChevalet(boolean b) {
		onChevalet = b;
	}
	
	public boolean getOnChevalet() {
		return onChevalet;
	}
	
	public void setCoord(int x, int y) {
		this.coordX = x;
		this.coordY = y;
	}
	
	public int getCoordX() {
		return this.coordX;
	}
	
	public int getCoordY() {
		return this.coordY;
	}
	
	public void resetLettre() {
		coordX = -1;
		coordY = -1;
		onChevalet = false;
		onPlat = false;
	}
	
	private void setPNG() {
		
	}
	
	public char getLettre() {
		return this.lettre;
	}
	
	public int getScore() {
		return this.score;
	}
	
	/*public void setImageView(ImageView iv) {
		

	}*/
	
	public ImageView getImageView() {
		/*Image A = new Image("file:src/toUse/image/Piece/Letter_" + lettre + ".png");
		ImageView imageOnPlat = new ImageView(A);
		imageOnPlat.setFitHeight(Fenetre.getHeightCase());
		imageOnPlat.setFitWidth(Fenetre.getWidthCase());*/
		//imageOnPlat = iv;
		return Fenetre.getImageViewLetter(posImageView);
	}
	
	static public int getScoreChar(char l) {
		switch (l) {
		case 'A':
		case 'E':
		case 'I':
		case 'N':
		case 'O':
		case 'R':
		case 'S':
		case 'T':
		case 'U':
		case 'L': {
			return 1;
		}
		case 'D':
		case 'G':
		case 'M': {
			return 2;
		}
		case 'B':
		case 'C':
		case 'P': {
			return 3;
		}
		case 'F':
		case 'H':
		case 'V': {
			return 4;
		}
		case 'J':
		case 'Q': {
			return 8;
		}
		case 'K':
		case 'W':
		case 'X':
		case 'Y':
		case 'Z': {
			return 10;
		}
		case ' ' :{
			return 0;
		
		}
		default :
			return 0;
		}
	}

	public int getPosImageView() {
		return posImageView;
	}

	public void setPosImageView(int posImageView) {
		this.posImageView = posImageView;
	}

	public boolean isOnPlat() {
		return onPlat;
	}

	public void setOnPlat(boolean onPlat) {
		this.onPlat = onPlat;
	}
	
}
