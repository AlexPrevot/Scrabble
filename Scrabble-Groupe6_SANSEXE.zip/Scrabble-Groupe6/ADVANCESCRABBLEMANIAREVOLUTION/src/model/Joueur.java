package model;

import java.io.Serializable;
import java.util.ArrayList;

public class Joueur implements Serializable{
	
	static ArrayList<Joueur> listJoueur = new ArrayList<Joueur>();
	static Joueur victorious;
	ArrayList<Lettre> lettrePose;
	int score = 0;
	private boolean hisTurn = false;
	private Chevalet c;
	String name;
	boolean hasFlushed = false;
	boolean turnPassed;
	
	public Joueur() {
		turnPassed = false;
		lettrePose = new ArrayList<Lettre>();
		Chevalet c1 = new Chevalet();
		this.c = c1;
		listJoueur.add(this);
		name = "Joueur " + (listJoueur.indexOf(this) + 1);
	}
	
	public boolean getTurnPassed() {
		return turnPassed;
	}
	
	public void setTurnPassed(boolean b) {
		this.turnPassed = b;
	}
	
	static public void setListJoueur(ArrayList<Joueur> j) {
		listJoueur = j;
	}
	
	static public void clearJoueur() {
		listJoueur.clear();
	}
	
	public String getName() {
		return name;
	}
	
	public void retrieveScoreActivePlayer(ArrayList<String> s) {
		int totalScore = 0;
		totalScore += getOriginalWordLetterScore(s.get(0));
		totalScore *= getOriginalWordBonus(s.get(0));

		
		s.remove(s.get(0));
		
		for(String st : s) {
			for(int i = 0; i < st.length(); i++) totalScore += Lettre.getScoreChar(st.charAt(i));
		}
		
		score += totalScore;

	}
	
	private int getOriginalWordLetterScore(String st) {
		String s = st;
		
		int putedLetterScore =0;
		
		for(Lettre l : lettrePose) {
			putedLetterScore += l.getScore()*Plateau.getCase(l.getCoordX(), l.getCoordY()).getCaseBonus();
			s = s.replaceFirst(""+l.getLettre(),"");
		}
		
		for(int i = 0; i < s.length(); i++) {
			putedLetterScore += Lettre.getScoreChar(s.charAt(i));
		}
		
		return  putedLetterScore;
	}
	
	
	private int getOriginalWordBonus(String s) {
		int bonusMul = 1;
		for(Lettre l : lettrePose) {
			bonusMul *= Plateau.getCase(l.getCoordX(), l.getCoordY()).getWordBonus();
		}
		
		return bonusMul;
	}
	
	public boolean getHasFlushed() {
		return hasFlushed;
	}
	
	public void setHasFlushed(boolean b) {
		hasFlushed = b;
	}
	
	public Chevalet getChevalet() {
		return this.c;
	}
	
	public void addScore(int x) {
		this.score += x;
	}
	
	public int getScore() {
		return this.score;
	}
	
	public boolean getTurn() {
		return this.hisTurn;
	}
	
	public void changeTurn() {
		this.hisTurn = !this.hisTurn;
	}
	
	public static Joueur getVictorious() {
		return victorious;
	}
	
	public static void setVictorious(Joueur j) {
		victorious = j;
	}
	
	public void addLettrePose(Lettre l) {
		
		int x = 0;
		for(Lettre n : lettrePose) {
			if(!(l.getCoordX() == n.getCoordX())){
				Plateau.setPoseHorizontal(true);
				Plateau.setPoseVertical(false);
			}
			if(!(l.getCoordY() == n.getCoordY())){
				Plateau.setPoseHorizontal(false);
				Plateau.setPoseVertical(true);
			}
			
			if(l.getCoordX() < n.getCoordX() || l.getCoordY() < n.getCoordY()) {
				x = lettrePose.indexOf(n);
				break;
			}
			if(lettrePose.indexOf(n) + 1 == lettrePose.size()) {
				x = -1;
			}
		}
		
		if(!(x == -1)) lettrePose.add(x,l);
		else lettrePose.add(l);
	}
	
	public ArrayList<Lettre> getLettrePose(){
		return lettrePose;
	}
	
	static public ArrayList<Joueur> getListJoueur() {
		return listJoueur;
	}

}
