package view;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import model.Joueur;
import model.Plateau;
import model.Scrabble;
import javafx.event.EventHandler;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class Menu implements EventHandler<ActionEvent>{

	static int heightScreen =500;
	static Stage stage;
	
	static Pane retour;
	static Pane buttonRetour;
	
	
	static public void ouvrireMenu() throws Exception {
		stage = new Stage();
		retour = new Pane();
		buttonRetour = new Pane();
		stage.setTitle("ADVANCESCRABBLEMANIAREVOLUTION-Menu");

		stage.setResizable(false);
		
		Group Interface = new Group();
		
		Image imageRetour = new Image("file:src/toUse/image/Retour1.png");
        ImageView imRetour = new ImageView(imageRetour);
        imRetour.setFitHeight(25);
        imRetour.setFitWidth(75);
        buttonRetour.getChildren().add(imRetour);
		
		
		retour.getChildren().add(buttonRetour);

		Image image = new Image("file:src/toUse/image/fondMenu.png");
		ImageView fondView = new ImageView(image);
		ImageView fondView2 = new ImageView(image);
		fondView2.setFitHeight(heightScreen-heightScreen/3);
		fondView2.setFitWidth(heightScreen);
		ImageView fondView3 = new ImageView(image);
		fondView3.setFitHeight(heightScreen-heightScreen/3);
		fondView3.setFitWidth(heightScreen);

		StackPane tout = new StackPane();
		tout.getChildren().add(fondView);
		Pane tout2 = new Pane();
		tout2.getChildren().add(fondView2);
		Pane tout3 = new Pane();
		tout3.getChildren().add(fondView3);
		
		
		Image imageButtonNewGame = new Image("file:src/toUse/image/JouerUp.png");
		ImageView imNewGame = new ImageView(imageButtonNewGame);
		imNewGame.setFitHeight(51);
		imNewGame.setFitWidth(200);
		Pane newGame = new Pane();
		newGame.getChildren().add(imNewGame);
		
		//Button loadGame = new Button("CHARGER UNE PARTIE");
		 newGame.setLayoutX(0);
	     newGame.setLayoutY(-102);
		Image imageButtonLoadGame = new Image("file:src/toUse/image/chargerUneSauvegardeUp.png");
		ImageView imLoadGame = new ImageView(imageButtonLoadGame);
		imLoadGame.setFitHeight(51);
		imLoadGame.setFitWidth(200);
		Pane loadGame = new Pane();
		loadGame.getChildren().add(imLoadGame);
		
		
		Interface.getChildren().add(newGame);
		Interface.getChildren().add(loadGame);

		tout.getChildren().add(Interface);

		Scene debut = new Scene(tout,heightScreen,heightScreen-heightScreen/3);
		Scene Partie = new Scene(tout2,heightScreen,heightScreen-heightScreen/3);
		Scene Sauvegarde = new Scene(tout3, heightScreen,heightScreen-heightScreen/3);


		Button valider = new Button("VALIDER");

		Image imageButtonS1 = new Image("file:src/toUse/image/Sauvegarde1.png");
        Image imageButtonS2 = new Image("file:src/toUse/image/Sauvegarde2.png");
        Image imageButtonS3 = new Image("file:src/toUse/image/Sauvegarde3.png");
        ImageView viewImageButtonS1 = new ImageView(imageButtonS1);
        ImageView viewImageButtonS2 = new ImageView(imageButtonS2);
        ImageView viewImageButtonS3 = new ImageView(imageButtonS3);
        
        Pane ButtonS1 = new Pane();
        ButtonS1.getChildren().add(viewImageButtonS1);
        viewImageButtonS1.setFitHeight(51);
        viewImageButtonS1.setFitWidth(200);
        ButtonS1.setLayoutX(150);
        ButtonS1.setLayoutY(62);
        
        Pane ButtonS2 = new Pane();
        ButtonS2.getChildren().add(viewImageButtonS2);
        viewImageButtonS2.setFitHeight(51);
        viewImageButtonS2.setFitWidth(200);
        ButtonS2.setLayoutX(150);
        ButtonS2.setLayoutY(140);
        
        
        Pane ButtonS3 = new Pane();
        ButtonS3.getChildren().add(viewImageButtonS3);
        viewImageButtonS3.setFitHeight(51);
        viewImageButtonS3.setFitWidth(200);
        ButtonS3.setLayoutX(150);
        ButtonS3.setLayoutY(218);
		
        tout3.getChildren().addAll(ButtonS1,ButtonS2,ButtonS3);


		Image imageButton2j = new Image("file:src/toUse/image/2joueursUp.png");
		ImageView imView2 = new ImageView(imageButton2j);
		imView2.setFitHeight(75);
		imView2.setFitWidth(75);
		Pane button2J = new Pane();
		button2J.getChildren().add(imView2);


		Image imageButton3j = new Image("file:src/toUse/image/3joueursUp.png");
		ImageView imView3 = new ImageView(imageButton3j);
		imView3.setFitHeight(75);
		imView3.setFitWidth(75);
		Pane button3J = new Pane();
		button3J.getChildren().add(imView3);


		Image imageButton4j = new Image("file:src/toUse/image/4joueursUp.png");
		ImageView imView4 = new ImageView(imageButton4j);
		imView4.setFitHeight(75);
		imView4.setFitWidth(75);
		Pane button4J = new Pane();
		button4J.getChildren().add(imView4);
		

		tout2.getChildren().add(button2J);
		tout2.getChildren().add(button3J);
		tout2.getChildren().add(button4J);

		button2J.setLayoutX(50);
        button2J.setLayoutY(heightScreen / 4);
        button3J.setLayoutX(217);
        button3J.setLayoutY(heightScreen / 4);
        button4J.setLayoutX(375);
        button4J.setLayoutY(heightScreen / 4);

      buttonRetour.setOnMouseClicked(new EventHandler<MouseEvent>(){

            @Override
            public void handle(MouseEvent args0) {
                stage.setScene(debut);
                stage.show();
            }

    });
        
		ButtonS1.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent args0) {
				stage.close();
				Scrabble.loadGame("src/toUse/save1.txt");
			}

	});
		
		ButtonS2.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent args0) {
				stage.close();
				Scrabble.loadGame("src/toUse/save2.txt");
			}

	});
		
		ButtonS3.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent args0) {
				stage.close();
				Scrabble.loadGame("src/toUse/save3.txt");
			}

	});
		
		loadGame.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent args0) {
				tout3.getChildren().remove(retour);
				tout3.getChildren().add(retour);
				stage.setScene(Sauvegarde);
				stage.show();
			}

	});
		
		newGame.setOnMouseClicked(new EventHandler<MouseEvent>(){
			
			@Override
			public void handle(MouseEvent args0) {
				tout2.getChildren().remove(retour);
				tout2.getChildren().add(retour);
				stage.setScene(Partie);
				stage.show();
			}

	});


		button2J.setOnMouseClicked(new EventHandler<MouseEvent>(){

				@Override
				public void handle(MouseEvent args0) {
					Plateau.clearGame();
					Joueur J1 = new Joueur();
					Joueur J2 = new Joueur();
					Plateau.setJoueurActif(J1);
					stage.close();
					Scrabble.newGame();
				}

		});

		button3J.setOnMouseClicked(new EventHandler<MouseEvent>(){

			@Override
			public void handle(MouseEvent args0) {
				Plateau.clearGame();
				Joueur J1 = new Joueur();
				Joueur J2 = new Joueur();
				Joueur J3 = new Joueur();
				Plateau.setJoueurActif(J1);
				stage.close();
				Scrabble.newGame();
			}
		});

    button4J.setOnMouseClicked(new EventHandler<MouseEvent>(){

      @Override
      public void handle(MouseEvent args0) {
    	  		Plateau.clearGame();
				Joueur J1 = new Joueur();
				Joueur J2 = new Joueur();
				Joueur J3 = new Joueur();
				Joueur J4 = new Joueur();
				Plateau.setJoueurActif(J1);
				stage.close();
				Scrabble.newGame();
      }
    });
		stage.setScene(debut);
		stage.show();
	}

	@Override
	public void handle(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
