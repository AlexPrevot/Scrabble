package view;

import javafx.stage.Stage;
import javafx.util.Duration;
import model.Case;
import model.Chevalet;
import model.Joueur;
import model.Lettre;
import model.Plateau;
import model.Sac;

import java.util.ArrayList;

import controller.Souris;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;

public class Fenetre extends Application{
	static String whatBoxIsOpen;
	static Stage primaryStage;
	static Stage victoryStage;
	static Stage saveStage;
	static private Group partie;
	static private Pane plateau;
	static private Pane chevalet;
	static private Pane sac;
	static private Pane valider;
	static private Pane scoreDisplayer;
	static private Pane retourMenu;
	static private Pane boutonSauvegarder;
	static private Pane sauvegarde_1;
	static private Pane sauvegarde_2;
	static private Pane sauvegarde_3;
	static private Pane wordDisplayer;
	static private Pane scriber;
	
	
	static private Text texteScore;
	
	static private int tailleFenetreX = 1000;
	static private int tailleFenetreY = 700; 

	static double lengthPlat = 528;
	static double heightPlat = 465;
	static double tabStartX = 22;
	static double tabStartY = 22.5;
	static double separatorX = 2;
	static double separatorY = 1;
	static double widthCase = 30.7;
	static double heightCase = 26.85;
	static double spaceBetweenCase = 1;
	
	static private Timeline animation;
	static private Timeline animationPioche;
	static private int angleApplicated =0;
	
	static ArrayList<ImageView> listLettreGraphique = new ArrayList<ImageView>();
	static ArrayList<Rectangle> listHider;
	
	static int tailleCase = 30;
	
	static String window;
	
	
	static public void ouvrirFenetre(String[] args, String s){
		window = s;
		launch(args);
		
	}
	
	
	@Override
	public void start(Stage stage) throws Exception {
		if(window == "jeu") ouvrirJeu();
		else Menu.ouvrireMenu();
		
	}
	
	public void ouvrirJeu() {
		whatBoxIsOpen = "fenetre";
		partie = new Group();
		plateau = new Pane();
		chevalet = new Pane();
		sac = new Pane();
		valider = new Pane();
		scoreDisplayer = new Pane();
		retourMenu = new Pane();
		boutonSauvegarder = new Pane();
		sauvegarde_1 = new Pane();
		sauvegarde_2 = new Pane();
		sauvegarde_3 = new Pane();
		wordDisplayer = new Pane();
		scriber = new Pane();
		saveStage = new Stage();
		

		texteScore = new Text("");
		
		primaryStage = new Stage();
		
		listHider = new ArrayList<Rectangle>();
		
		primaryStage.setTitle("ADVANCED SCRABBLE MANIA REVOLUTION");
		
		displayPlateau();
		
		Scene scene = new Scene(plateau,tailleFenetreX,tailleFenetreY);
		
		primaryStage.setResizable(false);
		
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	static public void fermerJeu() {
		primaryStage.close();
	}
	
	static public void fermerVictoire() {
		victoryStage.close();
	}
	
	static public String getWhatBoxIsOpen() {
		return whatBoxIsOpen;
	}
	
	static public void fermerSave() {
		saveStage.close();
	}
	
	static public void showVictoryBox() {
		whatBoxIsOpen = "victoire";
		fermerJeu();
		victoryStage = new Stage();
		
		Text victory = new Text();
		victory.setText("LE VAINQUEUR EST LE " + Joueur.getVictorious().getName() + " AVEC UN SCORE DE : " + Joueur.getVictorious().getScore());
		
		
		
		Image im = new Image("file:src/toUse/image/chevalet.jpg");
		ImageView imView = new ImageView(im);
		
		Image buttonRetour = new Image("file:src/toUse/image/Retour1.png");
		ImageView buttonView = new ImageView(buttonRetour);
		
		Image imVic = new Image("file:src/toUse/image/victoire.png");
		ImageView imVicView = new ImageView(imVic);
		
		imVicView.setFitWidth(312);
		imVicView.setFitHeight(44);
		
		buttonView.setFitHeight(51);
		buttonView.setFitWidth(200);
		
		Pane imFond = new Pane();
		Pane victoire = new Pane();
		
		victoire.getChildren().add(imVicView);
		victoire.setLayoutY(110-imVicView.getFitHeight()/2);
		victoire.setLayoutX(572/2 - (imVicView.getFitWidth()/2));
		
		imFond.getChildren().add(imView);
		
		plateau.getChildren().remove(retourMenu);
		retourMenu.setLayoutX(300);

		retourMenu.setLayoutY(5);

		retourMenu.getChildren().add(buttonView);
		Pane ecran = new Pane();
		
		victory.setLayoutY(victoire.getLayoutY() + imVicView.getFitHeight() + 10);
		victory.setLayoutX(572/2 - 150);
				
		ecran.getChildren().addAll(imFond,retourMenu,victoire, victory);
	
		Scene scene = new Scene(ecran,572,220);
		
		victoryStage.setScene(scene);
		victoryStage.show();
	}
	
	static public void sauvegardeScreen() {
		
		
		Image im = new Image("file:src/toUse/image/fondMenu.png");
		ImageView imView = new ImageView(im);
		
		imView.setFitHeight(218);
		imView.setFitWidth(512);
		
		Image imSave1 = new Image("file:src/toUse/image/Sauvegarde1.png");
		Image imSave2 = new Image("file:src/toUse/image/Sauvegarde2.png");
		Image imSave3 = new Image("file:src/toUse/image/Sauvegarde3.png");
		
		ImageView imViewSave1 = new ImageView(imSave1);
		imViewSave1.setFitHeight(51);
		imViewSave1.setFitWidth(150);
		
		ImageView imViewSave2 = new ImageView(imSave2);
		imViewSave2.setFitHeight(51);
		imViewSave2.setFitWidth(150);
		
		ImageView imViewSave3 = new ImageView(imSave3);
		imViewSave3.setFitHeight(51);
		imViewSave3.setFitWidth(150);
		
		sauvegarde_1.getChildren().add(imViewSave1);
		sauvegarde_1.setLayoutX(256-imViewSave1.getFitWidth()/2);
		sauvegarde_1.setLayoutY(10);
		
		sauvegarde_2.getChildren().add(imViewSave2);
		sauvegarde_2.setLayoutX(256-imViewSave2.getFitWidth()/2);
		sauvegarde_2.setLayoutY(75);
		
		sauvegarde_3.getChildren().add(imViewSave3);
		sauvegarde_3.setLayoutX(256-imViewSave3.getFitWidth()/2);
		sauvegarde_3.setLayoutY(145);
		
		Pane truc = new Pane();
		
		truc.getChildren().add(imView);
		truc.getChildren().addAll(sauvegarde_1,sauvegarde_2,sauvegarde_3);
		
		Scene scene = new Scene(truc,512,218);
		
		saveStage.setScene(scene);
		saveStage.show();
	}
	
	static public ImageView getImageViewLetter(int i) {
		return listLettreGraphique.get(i);
	}
	
	static public ArrayList<ImageView> getListLettreGraphique(){
		return listLettreGraphique;
	}
	
	static public void initializeViewLetter(Lettre l) {
		Image i = new Image("file:src/toUse/image/Piece/Letter_" + l.getLettre() + ".png");
		ImageView imageOnPlat = new ImageView(i);
		imageOnPlat.setFitHeight(heightCase);
		imageOnPlat.setFitWidth(widthCase);
		imageOnPlat.setLayoutX(l.getCoordX());
		imageOnPlat.setLayoutY(l.getCoordY());
		listLettreGraphique.add(imageOnPlat);
		l.setPosImageView(listLettreGraphique.indexOf(imageOnPlat));
		
		if(l.isOnPlat()) showLetterOnPlat(l, l.getCoordX(), l.getCoordY());
	}
	
	static private void displayRetourMenu() {
        Image imageRetour = new Image("file:src/toUse/image/Retour1.png");
        ImageView imRetour = new ImageView(imageRetour);
        imRetour.setFitHeight(50);
        imRetour.setFitWidth(150);
        retourMenu.setLayoutX(-166);
        retourMenu.setLayoutY(-45);
        
        retourMenu.getChildren().add(imRetour);
        
        plateau.getChildren().add(retourMenu);
    }
	
	static private void displayPlateau() {
		Image imageFond = new Image("file:src/toUse/image/table.jpg");
		ImageView fondApp = new ImageView(imageFond);
		
		fondApp.setFitWidth(tailleFenetreX);
		fondApp.setFitHeight(tailleFenetreY);
		fondApp.setLayoutX(-(tailleFenetreX/2-lengthPlat/2));
		fondApp.setLayoutY(-(tailleFenetreY/2-heightPlat/2));
		
		plateau.getChildren().add(fondApp);
		
		plateau.getChildren().add(partie);
		plateau.setLayoutX(tailleFenetreX/2-lengthPlat/2);
		plateau.setLayoutY(tailleFenetreY/2-heightPlat/2);
		
		Image imageGrille = new Image("file:src/toUse/image/grille-scrabble.png");
		ImageView mv = new ImageView(imageGrille);
		
		displayImageChevalet();
		
		if(!Sac.getListLettre().isEmpty()) displaySac("file:src/toUse/image/pioche.png");
		else displaySac("file:src/toUse/image/empty.png");
		
		displayRetourMenu();
		
		displayValider();
		
		displaySauvegarder();
		
		displayWordDisplayer();
				
		Souris.mouseAction(partie,plateau,chevalet,sac,valider,retourMenu,boutonSauvegarder,sauvegarde_1,sauvegarde_2,sauvegarde_3);
		partie.getChildren().add(mv);

	}
	
	static private void displayValider() {
		Image i = new Image("file:src/toUse/image/Valider1.png");
		ImageView ValiderIV = new ImageView(i);
		
		valider.getChildren().add(ValiderIV);		
		
		valider.setLayoutX(535);
		valider.setLayoutY(200);
		
		ValiderIV.setFitWidth(150);
		ValiderIV.setFitHeight(51);

		plateau.getChildren().add(valider);
	}
	
	static private void displayWordDisplayer() {
		Image i = new Image("file:src/toUse/image/boutonDefaut.png");
		ImageView wordDisplayerIV = new ImageView(i);
		
		wordDisplayerIV.setFitWidth(180);
		wordDisplayerIV.setFitHeight(100);
		
		wordDisplayer.getChildren().add(wordDisplayerIV);
		wordDisplayer.setLayoutX(525);
		
		wordDisplayer.getChildren().add(scriber);
		
		plateau.getChildren().remove(wordDisplayer);
		plateau.getChildren().add(wordDisplayer);
	}
	
	static public void displayWord(ArrayList<String> list) {
		scriber.getChildren().clear();
		int incr =0;
		
		scriber.setLayoutY(30);
		
		for(String s : list) {
			Text t = new Text();
			if (Plateau.doWordExists(s)) t.setText(s + " existe dans le dictionnaire.");
			else t.setText(s + " n'existe pas.");
			t.setLayoutY(10*incr);
			t.setLayoutX(10);
			scriber.getChildren().add(t);
			incr++;
		}
	}
	
	
	
	static private void displayImageChevalet() {		
		Rectangle rec = new Rectangle();
		
		rec.setWidth(200);
		rec.setHeight(40);
		
		rec.setArcHeight(15);
		rec.setArcWidth(15);
		
		rec.setFill(Color.LIGHTGREEN);
		
		rec.setLayoutY(-40);
		scoreDisplayer.getChildren().add(rec);
		chevalet.getChildren().add(scoreDisplayer);
		texteScore.setText(Plateau.getJoueurActif().getName() + " : " + Plateau.getJoueurActif().getScore());
		texteScore.setFill(Color.DARKRED);
		
		texteScore.setLayoutY(-15);
		
	
		scoreDisplayer.getChildren().add(texteScore);
		
		Image imageChevalet = new Image("file:src/toUse/image/chevalet.jpg");
		ImageView viewChevalet = new ImageView(imageChevalet);

		chevalet.getChildren().add(viewChevalet);
		
		
		chevalet.setLayoutX(-((572-528)/2));
		chevalet.setLayoutY(tailleFenetreY-150);
		
		
		plateau.getChildren().add(chevalet);
	}
	
	public static void displaySac(String cheminImage) {
		sac.getChildren().clear();
		Image imageSac = new Image(cheminImage);
		ImageView viewSac = new ImageView(imageSac);
		
		sac.getChildren().add(viewSac);
		
		viewSac.setFitHeight(170);
		viewSac.setFitWidth(110);
		
		sac.setLayoutX(-130);
		sac.setLayoutY(200);
		
		plateau.getChildren().remove(sac);
		
		plateau.getChildren().add(sac);
	}
	
	public static void displaySauvegarder() {	
	 Image imageSauvegarderUp = new Image("file:src/toUse/image/SauvegarderUp.png");
	 ImageView viewImageSauvegarderUp = new ImageView(imageSauvegarderUp);
	        
	 viewImageSauvegarderUp.setFitHeight(51);
	 viewImageSauvegarderUp.setFitWidth(150);
	        
	 boutonSauvegarder.getChildren().add(viewImageSauvegarderUp);
	        
	 boutonSauvegarder.setLayoutX(535);
	 boutonSauvegarder.setLayoutY(300);

	 plateau.getChildren().remove(boutonSauvegarder);
	 plateau.getChildren().add(boutonSauvegarder);
	}
	
	static public void  upChevalet() {
		if(!(animation == null)) animation.stop();
		animation = new Timeline(new KeyFrame(
				Duration.millis(10),
				(evt) -> {
					if(chevalet.getLayoutY() > 440) chevalet.setLayoutY(chevalet.getLayoutY() - 2);
					else animation.stop();
		}));
		animation.setCycleCount(Timeline.INDEFINITE);
		animation.play();
	}
	
	static public void downChevalet() {
		if(!(animation == null)) animation.stop();
		animation = new Timeline(new KeyFrame(
				Duration.millis(10),
				(evt) -> {
					if(chevalet.getLayoutY() < 550) chevalet.setLayoutY(chevalet.getLayoutY() + 2);
					else animation.stop();
		}));
		animation.setCycleCount(Timeline.INDEFINITE);
		animation.play();
	}
	
	static public void animationSacPioche(int dir) {
		boolean commenceGauche = dir == 1 && angleApplicated < 0 ? true: false;
		int angle = dir * 5;
		Rotate r = new Rotate(angle,sac.getWidth()/2,sac.getHeight()/2);
		if(!(animationPioche == null)) animationPioche.stop();
		animationPioche = new Timeline(new KeyFrame(
				Duration.millis(10),
				(evt) -> {
					sac.getTransforms().add(r);
					angleApplicated += angle;
					
					if(angleApplicated > 20 && !commenceGauche) {
						animationPioche.stop();
						animationSacPioche(-1);

					}
					
					if(angleApplicated < -20 && !commenceGauche) {
						animationPioche.stop();
						animationSacPioche(1);
					}
					
					if(commenceGauche && angleApplicated > -angle) {
						animationPioche.stop();
					}
		}));
		animationPioche.setCycleCount(Timeline.INDEFINITE);
		animationPioche.play();
	}
	
	static public void updateChevalet(Chevalet c) {
		int n = Plateau.getJoueurActif().getScore();
		String s = Plateau.getJoueurActif().getName();
		texteScore.setText(Plateau.getJoueurActif().getName() + " : " + Plateau.getJoueurActif().getScore());
		for(Lettre l : c.getListLettre()) {
			showLetterOnChevalet(l);
		}
	}
	
	static public void hideChevalet(Chevalet c) {
		for(Lettre l : c.getListLettre()) {
			chevalet.getChildren().remove(l.getImageView());
		}
	}
	
	static public void showLetterOnPlat(Lettre l, int coordX, int coordY) {
		
		l.getImageView().setLayoutX(convertTabXToX(coordX));
		l.getImageView().setLayoutY(convertTabYToY(coordY));
		
		l.getImageView().setFitHeight(Fenetre.getHeightCase());
		l.getImageView().setFitWidth(Fenetre.getWidthCase());

		partie.getChildren().remove(l.getImageView());
		partie.getChildren().add(l.getImageView());
	}
	
	static public void showLetterOnChevalet(Lettre l) {
		chevalet.setLayoutY(440);
		
		plateau.getChildren().remove(l.getImageView());
		
		chevalet.getChildren().remove(l.getImageView());
		chevalet.getChildren().add(l.getImageView());
		l.getImageView().setLayoutX(l.getCoordX());
		l.getImageView().setLayoutY(l.getCoordY());
		
		l.getImageView().setFitHeight(1.5*Fenetre.getHeightCase());
		l.getImageView().setFitWidth(1.5*Fenetre.getWidthCase());		
	}
	
	static public void hideNonAccessibleCase() {
		
		for(Rectangle r : listHider) {
			plateau.getChildren().remove(r);
		}
		
		for(int i =0; i<15; i++) {
			for(int j = 0; j < 15; j++) {
				if(!Plateau.getCase(j, i).getCanBeFilled() && !Plateau.getJoueurActif().getLettrePose().contains(Plateau.getCase(j, i).getCaseLettre())) {
					Rectangle rec = new Rectangle();
					rec.setLayoutX(convertTabXToX(j));
					rec.setLayoutY(convertTabYToY(i));
					
					rec.setWidth(widthCase);
					rec.setHeight(heightCase);
					
					rec.setOpacity(0.2);
					plateau.getChildren().add(rec);
					listHider.add(rec);
				}
			}
		}
	}
	
	static public void pressButtonValider() {
		Image i = new Image("file:src/toUse/Image/Valider2.png");
		ImageView iv = new ImageView(i);
		
		iv.setFitWidth(150);
		iv.setFitHeight(51);
		
		valider.getChildren().add(iv);
	}
	

	
	static public Pane getValider() {
		return valider;
	}
	
	static public Pane getPlateau() {
		return plateau;
	}
	
	static public Group getPartie() {
		return partie;
	}
	
	static public Pane getChevalet() {
		return chevalet;
	}
	
	static public Pane getSac() {
		return sac;
	}
	
	static public double getWidthCase() {
		return widthCase;
	}
	
	static public double getHeightCase() {
		return heightCase;
	}
	
	static public boolean validPosLetter() {
		boolean value = true;
		
		
		
		return value;
	}
	
	static public double convertTabXToX(int posX) {
		return tabStartX + separatorX + (widthCase + spaceBetweenCase)*posX;
	}
	
	static public double convertTabYToY(int posY) {
		return tabStartY + separatorY + (heightCase + spaceBetweenCase)*posY;
	}
	
	static public int convertXToTabX(double posX) {
		return (int) ((posX - tabStartX - separatorX)/(widthCase + spaceBetweenCase));
	}
	
	static public int convertYToTabY(double posY) {
		return (int) ((posY - tabStartY - separatorY)/(heightCase + spaceBetweenCase));
	}
	
	
}
